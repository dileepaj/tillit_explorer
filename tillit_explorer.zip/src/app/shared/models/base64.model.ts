export interface IBase64 {
    data: string;
}
