export interface ErrorMessage {
    errorType: string;
    errorTitle: string;
    errorMessage: string;
    errorMessageSecondary: string;
}