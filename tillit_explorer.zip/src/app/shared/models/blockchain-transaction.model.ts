export interface IBlockchainTransaction {
    Txnhash: string;
    Url: string;
    Identifier: string;
    TdpId: string;
}