export interface SearchResult {
    data: string;
}
