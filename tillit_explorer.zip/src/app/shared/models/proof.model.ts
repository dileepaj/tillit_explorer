export interface Proofs {
        hashtracified: string;
        hashblockchain: string;
        Id: string;
        TenantID: string;
        StageID: string;
        UserID: string;
        Timestamp: string;
        WorkflowRevision: string;
        TraceabilityID: string;
        identifierId: string;
        Type: string;

}
