import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorIdComponent } from './components/error-id/error-id.component';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
