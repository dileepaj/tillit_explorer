import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-element-divider',
  templateUrl: './element-divider.component.html',
  styleUrls: ['./element-divider.component.css']
})
export class ElementDividerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
